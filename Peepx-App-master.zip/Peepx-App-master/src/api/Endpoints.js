const BASE_URL = 'http://3.130.226.194/v1';
// const BASE_URL = 'http://192.168.0.11:8080/v1';

export const userEndpoint = `${BASE_URL}/users`;
export const loginEndpoint = `${BASE_URL}/login`;
export const nearByUsersEndpoint = `${BASE_URL}/nearByUsers`;
