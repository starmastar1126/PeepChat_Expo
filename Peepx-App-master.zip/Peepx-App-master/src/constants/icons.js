export const tabBarIcons = {
    NewsFeed: '@3xhand-leaf-(1)',
    Info: '@3xhand-leaf-(1)',
    Peep: 'multiple-users-silhouette@3x',
    Notifications: 'alarm',
    Profile: 'user',
    ToDo: 'ios-list-box',
};
