export const images = {
    logo: require('../../assets/images/logo.png'),
    icon: require('../../assets/images/logoicon.png'),
    lock: require('../../assets/images/lock.png'),
    alphaCount: require('../../assets/images/alphaCountSub.png'),
    googleButton: require('../../assets/images/googleButton.png'),
};
